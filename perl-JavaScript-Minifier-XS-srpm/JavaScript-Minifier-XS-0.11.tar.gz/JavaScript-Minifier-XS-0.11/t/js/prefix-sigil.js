/* whitespace after "prefix" sigils should get removed */
function foo(   ){	
    alert("foo!");
}
