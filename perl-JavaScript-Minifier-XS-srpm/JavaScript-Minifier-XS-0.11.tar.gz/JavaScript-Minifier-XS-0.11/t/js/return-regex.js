/* should be able to return a regex from a function */
function foo() {
    return /\d{1,2}/;
}
