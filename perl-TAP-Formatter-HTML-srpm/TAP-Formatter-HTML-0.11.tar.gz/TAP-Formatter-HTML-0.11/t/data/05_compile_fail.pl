use strict;
use warnings;

use Test::More 'no_plan';

it'd all be ok, except I'm writting some silly comment here
without actually remembering to put the # comment in...

ok(1, 'im ok');
is(1, 1, 'one is one');
like('abc', qr/b/, 'contains b');

