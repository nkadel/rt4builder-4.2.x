use strict;
use warnings;

use Test::More skip_all => 'likity skipity';

fail('dont run me');
